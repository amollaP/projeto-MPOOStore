package mpooStore.app;

import mpooStore.controller.AberturaController;
import mpooStore.controller.GanharCupomController;
import mpooStore.model.BaseDados;
import mpooStore.model.CPFException;
import mpooStore.model.GeradorCupom;
import mpooStore.model.GerenciadorCupom;
import mpooStore.model.TempoOferta;
import mpooStore.view.AberturaView;
import mpooStore.view.GanharCupomView;

public class App {
	public static void main(String[] args) throws CPFException {
		BaseDados.createBase();
		AberturaView aberturaView = new AberturaView();
		GanharCupomView ganharCupomView =  new GanharCupomView();
		AberturaController aberturaController =  new AberturaController(aberturaView, ganharCupomView);
		GerenciadorCupom gerenciadorCupom = new GerenciadorCupom();
		GanharCupomController ganharCupomController = new GanharCupomController(ganharCupomView,aberturaView, gerenciadorCupom);
		
		TempoOferta tempoOferta = new TempoOferta(gerenciadorCupom);
		tempoOferta.start();

		GeradorCupom geradorCupom = new GeradorCupom(gerenciadorCupom);
		geradorCupom.start();
		
	}

}
