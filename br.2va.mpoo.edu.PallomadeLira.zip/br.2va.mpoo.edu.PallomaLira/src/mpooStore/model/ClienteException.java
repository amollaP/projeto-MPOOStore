package mpooStore.model;

public class ClienteException extends Exception{
	
	public ClienteException() {
		super();
	}
	
	
	public ClienteException(String mensagem) {

		super(mensagem);
	}
	
}
