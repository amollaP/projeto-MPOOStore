package mpooStore.model;

public class CupomException extends Exception {
	
	
	public CupomException() {
		super();
	}

	public CupomException(String mensagem) {
		super(mensagem);
	}
}
